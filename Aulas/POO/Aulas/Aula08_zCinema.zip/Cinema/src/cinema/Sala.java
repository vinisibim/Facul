/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cinema;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Juliana
 */
public class Sala {
    private int numero;
    private List<Assento> assentos = new ArrayList<Assento>();

    public int getNumero() {
        return numero;
    }
    public void setNumero(int numero) {
        this.numero = numero;
    }

    public List<Assento> getAssentos() {
        return assentos;
    }
    public void setAssentos(List<Assento> assentos) {
        this.assentos = assentos;
    }
}
