/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cinema;

/**
 *
 * @author Juliana
 */
public class Assento {
    private char fileira;
    private int numero;
    private boolean livre;

    public char getFileira() {
        return fileira;
    }
    public void setFileira(char fileira) {
        this.fileira = fileira;
    }

    public int getNumero() {
        return numero;
    }
    public void setNumero(int numero) {
        this.numero = numero;
    }

    public boolean isLivre() {
        return livre;
    }
    public void setLivre(boolean livre) {
        this.livre = livre;
    }
    
    
}
