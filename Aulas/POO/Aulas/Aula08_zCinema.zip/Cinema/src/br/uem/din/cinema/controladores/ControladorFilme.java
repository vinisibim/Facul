/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.uem.din.cinema.controladores;

import cinema.Filme;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Juliana
 */
public class ControladorFilme {
    private List<Filme> filmes = new ArrayList<>();
    
    public Filme criarFilme(String titulo){
        Filme novoFilme = new Filme();
        novoFilme.setTitulo(titulo);
        return novoFilme;
    }
    
    public Filme consultarFilme(String titulo){
        for(Filme filme: this.filmes){
            if(filme.getTitulo().contains(titulo)){
                return filme;
            }
        }
        return null;
    }
    
    public List<Filme> getFilmes() {
        return filmes;
    }
    public void setFilmes(List<Filme> filmes) {
        this.filmes = filmes;
    }
}
