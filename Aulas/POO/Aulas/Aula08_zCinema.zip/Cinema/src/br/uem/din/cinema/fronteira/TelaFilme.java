/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.uem.din.cinema.fronteira;

import br.uem.din.cinema.controladores.ControladorFilme;
import cinema.Filme;
import java.util.Scanner;

/**
 *
 * @author Juliana
 */
public class TelaFilme {
    private Scanner scan = new Scanner(System.in);
    private ControladorFilme controladorFilme = new ControladorFilme();
    private String titulo;
    private int opcao;
    
    public int menu(){
        System.out.println("0. Sair");
        System.out.println("1. Inserir novo filme");
        System.out.println("2. Consultar filme");
        System.out.println("Digite a opcao: ");
        opcao = scan.nextInt();
        scan.nextLine();//para "limpar o \n do buffer"
        return opcao;
    }
    
    public void inserir(){
        System.out.println("Informe o titulo do filme:");
        titulo = scan.nextLine();
        controladorFilme.getFilmes().add(controladorFilme.criarFilme(titulo));
    }
    
    public void consultar(){
        System.out.println("Informe o título do filme para a busca:");
        titulo = scan.nextLine();
        Filme achado = controladorFilme.consultarFilme(titulo);
        if (achado != null){
            System.out.println("Encontrado: " + achado.getTitulo());
        }
        else{
            System.out.println("Filme nao encontrado ou nao cadastrado.");
        }
    }
    
    public void iniciar(){
        do{
            opcao = menu();
            switch (opcao){
                case 1: inserir(); break;
                case 2: consultar(); break;
            }
        }while(opcao != 0);
    }
}
