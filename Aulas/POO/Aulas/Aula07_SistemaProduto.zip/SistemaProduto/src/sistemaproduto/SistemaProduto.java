/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemaproduto;

/**
 *
 * @author Juliana
 */
public class SistemaProduto {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Fornecedor fornecedor1 = new Fornecedor();
        fornecedor1.setNome("F1");
        fornecedor1.setEmail("f@gmail");
        fornecedor1.setTelefone("99999");
        
        Produto produto1 = new Produto();
        produto1.setNome("Omo");
        produto1.setCodigo(123);
        produto1.setPreco(17.99);
        produto1.setFornecedor(fornecedor1);
        
        Produto produto2 = new Produto("Ariel", 333);
        produto2.setFornecedor(fornecedor1);
        
        System.out.println("Produto 1: " + produto1.getNome());
        System.out.println("Fornecedor do Produto: " + produto1.getFornecedor().getNome());
        System.out.println("Produto 2: " + produto2.getNome());
    }
    
}
